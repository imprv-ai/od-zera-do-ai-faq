import requests
import streamlit as st
from typing import List, Optional


def extract_payer_emails(json_response: dict) -> List[str]:
    payer_emails = []
    for item in json_response["data"]:
        payer_email = item["payer_email"]
        payer_emails.append(payer_email)
    return payer_emails

def get_bmac_supporters(access_token=None):
    if access_token is None:
        access_token = st.secrets["bmac_api_key"]

    url = "https://developers.buymeacoffee.com/api/v1/supporters"
    headers = {"Authorization": f"Bearer {access_token}"}
    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        try:
            return extract_payer_emails(response.json())
        except Exception as e:
            st.error("BMC API nie zwróciło poprawnego JSON-a. Sprawdź klucz API lub endpoint.")
            return []
    else:
        st.error(f"BMC API error: {response.status_code} - {response.text[:200]}")
        return []

def is_bmac_subscriber(email: str) -> bool:
    try:
        return email in get_bmac_supporters()
    except Exception as e:
        st.error(f"Error checking BMC subscription: {str(e)}")
        return False

def add_bmc_auth(required: bool = True, 
                 show_redirect_button: bool = True, 
                 subscription_button_text: str = 'Subscribe now!',
                 button_color: str = "#FD504D", 
                 use_sidebar: bool = True):

    if not st.user.is_logged_in:
        if use_sidebar:
            with st.sidebar:
                if st.button("Zaloguj się", key="login_button_sidebar"):
                    st.login()
        return

    user_email = st.user.email
    is_subscribed = is_bmac_subscriber(user_email)

    if not is_subscribed:
        if show_redirect_button:
            if use_sidebar:
                with st.sidebar:
                    st.link_button(
                        subscription_button_text,
                        st.secrets["bmac_link"],
                        use_container_width=True
                    )
            else:
                st.link_button(
                    subscription_button_text,
                    st.secrets["bmac_link"],
                    use_container_width=True
                )
        st.session_state.user_subscribed = False
        if required:
            st.stop()
    else:
        st.session_state.user_subscribed = True
