
import streamlit as st
import pandas as pd  # type: ignore
import psycopg2  # type: ignore
from datetime import datetime, timezone
from openai import OpenAI
from bmc_auth import add_bmc_auth  # Tymczasowy import zamiast st_paywall

openai_client = OpenAI(api_key=st.secrets["OPENAI_API_KEY"])


#
# database & openai
#
@st.cache_resource
def get_connection():
    return psycopg2.connect(
        dbname=st.secrets["database"],
        user=st.secrets["username"],
        password=st.secrets["password"],
        host=st.secrets["host"],
        port=st.secrets["port"],
        sslmode=st.secrets["sslmode"]
    )


def insert_usage(email, output_tokens, input_tokens, input_text):
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO usages (google_user_email, output_tokens, input_tokens, input_text) VALUES (%s, %s, %s, %s)
            """, (email, output_tokens, input_tokens, input_text))
            conn.commit()


def get_current_month_usage_df(email):
    with get_connection() as conn:
        now = datetime.now(timezone.utc)
        start_date = datetime(now.year, now.month, 1)
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM usages WHERE google_user_email = %s AND created_at >= %s", (email, start_date))
            rows = cur.fetchall()
            columns = [desc[0] for desc in cur.description]
            df_usage = pd.DataFrame(rows, columns=columns)

    return df_usage


def create_story(story_prompt):
    if not st.user.email:
        raise Exception("User is not logged in")

    response = openai_client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {
                "role": "system",
                "content": """
                    Jesteś opowiadaczem historii.
                    Twórz krótkie opowiadania na podstawie podanego tekstu.
                    Opowiadania powinny być wciągające i zaskakujące.
                    Mają być zbudowane wokół struktury:
                    - wstęp
                    - rozwinięcie
                    - zakończenie

                    Opowiadanie nie powinno być krótsze niż 100 słów.
                """
            },
            {"role": "user", "content": story_prompt}
        ]
    )
    usage = {}
    if response.usage:
        usage = {
            "completion_tokens": response.usage.completion_tokens,
            "prompt_tokens": response.usage.prompt_tokens,
            "total_tokens": response.usage.total_tokens,
        }

    insert_usage(
        email=st.user.email,
        output_tokens=usage['completion_tokens'],
        input_tokens=usage['prompt_tokens'],
        input_text=story_prompt,
    )

    return {
        "role": "assistant",
        "content": response.choices[0].message.content,
        "usage": usage,
    }


#
# MAIN
#
_, c, _ = st.columns([2, 2, 2])
with c:
    st.image("logo.png")

st.title("Generator krótkich opowiadań 📖")
st.write("""
Użyj tej aplikacji, aby wygenerować krótkie opowiadania. Wprowadź swój tekst w poniższym polu tekstowym,
a następnie kliknij przycisk 'Generuj'. ✨
""")


# Zmieniony sposób logowania
if st.user.is_logged_in:
    st.session_state['user_input'] = st.text_area("Wprowadź swój tekst:", max_chars=1000)
    if st.button("Generuj 🚀", disabled=not st.session_state['user_input'].strip(), use_container_width=True):
        st.session_state['story'] = create_story(st.session_state['user_input'])

    if st.session_state.get('story'):
        st.write("### Twoje wygenerowane opowiadanie:")
        st.write(st.session_state['story']['content'])

        st.download_button(
            label="Pobierz wygenerowane opowiadanie",
            data=st.session_state['story']['content'],
            file_name="wygenerowane_opowiadanie.txt",
            mime="text/plain",
            use_container_width=True,
        )

with st.sidebar:
    st.image("logo.png", width=150)
    st.title("Generator krótkich opowiadań 📖")
    st.link_button("Polityka prywatności", "https://od-zera-do-ai-assets.fra1.cdn.digitaloceanspaces.com/privacy_policy.pdf")
    st.link_button("Regulamin", "https://od-zera-do-ai-assets.fra1.cdn.digitaloceanspaces.com/regulations.pdf")

    # Zmieniony sposób logowania
    if not st.user.is_logged_in:
        if st.button("Zaloguj się"):
            st.login()
    else:
        st.write(f"Jesteś zalogowany jako: {st.user.name}")
        try:
            add_bmc_auth(
                required=False,
                use_sidebar=True,
                subscription_button_text="Subskrybuj!",
            )
        except KeyError:
            pass
        if st.button("Wyloguj"):
            st.logout()

    if st.user.is_logged_in:

        usage_df = get_current_month_usage_df(st.user.email)
        st.write(f"W tym miesiącu użyłeś")
        c0, c1 = st.columns([1, 1])
        with c0:
            st.metric("Input tokenów", usage_df['input_tokens'].sum())
        with c1:
            st.metric("Output tokenów", usage_df['output_tokens'].sum())
